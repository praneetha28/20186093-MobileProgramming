package com.example.shoppingcart.Prevalent;
import com.example.shoppingcart.Model.Users;

public class Prevalent {

    public static Users currentOnlineUsers;
    public static String phonekey = "UserPhone";
    public static String passwordkey = "UserPassword";
}

